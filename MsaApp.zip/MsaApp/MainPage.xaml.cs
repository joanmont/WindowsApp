﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text.RegularExpressions;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace MsaApp
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }

        private void Length_Button_Click(object sender, RoutedEventArgs e)
        {
            ComboBoxItem inputUnit = (ComboBoxItem)lengthUnit.SelectedItem;
            string lUnit = inputUnit.Name.ToString();
            ComboBoxItem outputUnit = (ComboBoxItem)lengthUnitOutput.SelectedItem;
            string lUnitOut = outputUnit.Name.ToString();

            if (!string.IsNullOrWhiteSpace(lengthInput.Text))
            {
                String length = lengthInput.Text;
                Convert_Length(length, lUnit, lUnitOut);
            }
            else
            {
                lengthOutput.Text = "";
            }
        }

        private async void Convert_Length(string length, string lengthUnit, string lengthUnitOut)
        {
            double lengthDouble;
            Boolean canConvert = Double.TryParse(length, out lengthDouble);

            if (canConvert)
            {
                if (lengthUnit.Equals("kmIn"))
                {
                    if (lengthUnitOut.Equals("kmOut"))
                    {
                        lengthOutput.Text = lengthDouble.ToString();
                    }
                    else if (lengthUnitOut.Equals("mOut"))
                    {
                        lengthOutput.Text = (lengthDouble * 1000).ToString();
                    }
                    else if (lengthUnitOut.Equals("milesOut"))
                    {
                        lengthOutput.Text = (lengthDouble * 0.621371).ToString();
                    }
                    else
                    {
                        lengthOutput.Text = (lengthDouble * 3280.84).ToString();
                    }
                }
                else if (lengthUnit.Equals("mIn"))
                {
                    if (lengthUnitOut.Equals("kmOut"))
                    {
                        lengthOutput.Text = (lengthDouble * 0.001).ToString();
                    }
                    else if (lengthUnitOut.Equals("mOut"))
                    {
                        lengthOutput.Text = lengthDouble.ToString();
                    }
                    else if (lengthUnitOut.Equals("milesOut"))
                    {
                        lengthOutput.Text = (lengthDouble * 0.000621371).ToString();
                    }
                    else
                    {
                        lengthOutput.Text = (lengthDouble * 3.28084).ToString();
                    }
                }
                else if (lengthUnit.Equals("milesIn"))
                {
                    if (lengthUnitOut.Equals("kmOut"))
                    {
                        lengthOutput.Text = (lengthDouble * 1.60934).ToString();
                    }
                    else if (lengthUnitOut.Equals("mOut"))
                    {
                        lengthOutput.Text = (lengthDouble * 1609.34).ToString();
                    }
                    else if (lengthUnitOut.Equals("milesOut"))
                    {
                        lengthOutput.Text = lengthDouble.ToString();
                    }
                    else
                    {
                        lengthOutput.Text = (lengthDouble * 5280).ToString();
                    }
                }
                else
                {
                    if (lengthUnitOut.Equals("kmOut"))
                    {
                        lengthOutput.Text = (lengthDouble * 0.0003048).ToString();
                    }
                    else if (lengthUnitOut.Equals("mOut"))
                    {
                        lengthOutput.Text = (lengthDouble * 0.3048).ToString();
                    }
                    else if (lengthUnitOut.Equals("milesOut"))
                    {
                        lengthOutput.Text = (lengthDouble * 0.000189394).ToString();
                    }
                    else
                    {
                        lengthOutput.Text = lengthDouble.ToString();
                    }
                }
            }
            else
            {
                MessageDialog msgDialog = new MessageDialog("Please enter a valid numeric value!", "Length Conversion Error");
                await msgDialog.ShowAsync();
            }
        }
    }
}
